-- ============================================================================
-- 01_schema_ddl.sql
-- Capa Relacional ACID (PostgreSQL): Identidad Maestra, Personal, Camas y Admisiones
-- ============================================================================

CREATE SCHEMA IF NOT EXISTS hospitalizacion_acid;
SET search_path TO hospitalizacion_acid;

-- Limpieza previa si existe
DROP TABLE IF EXISTS signos_vitales_log CASCADE;
DROP TABLE IF EXISTS admisiones CASCADE;
DROP TABLE IF EXISTS camas CASCADE;
DROP TABLE IF EXISTS medicos CASCADE;
DROP TABLE IF EXISTS pacientes CASCADE;

-- 1. Tabla Maestra de Pacientes
CREATE TABLE pacientes (
    paciente_id VARCHAR(20) PRIMARY KEY,
    nombre_completo VARCHAR(120) NOT NULL,
    fecha_nacimiento DATE NOT NULL,
    grupo_sanguineo VARCHAR(5) CHECK (grupo_sanguineo IN ('A+','A-','B+','B-','AB+','AB-','O+','O-')),
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Tabla Maestra de Médicos
CREATE TABLE medicos (
    medico_id VARCHAR(20) PRIMARY KEY,
    nombre_completo VARCHAR(120) NOT NULL,
    especialidad VARCHAR(80) NOT NULL,
    registro_profesional VARCHAR(40) UNIQUE NOT NULL
);

-- 3. Tabla de Gestión de Camas
CREATE TABLE camas (
    cama_id VARCHAR(15) PRIMARY KEY,
    servicio VARCHAR(50) NOT NULL,
    estado VARCHAR(20) NOT NULL CHECK (estado IN ('DISPONIBLE', 'OCUPADA', 'MANTENIMIENTO'))
);

-- 4. Tabla Transaccional de Admisiones
CREATE TABLE admisiones (
    admision_id SERIAL PRIMARY KEY,
    paciente_id VARCHAR(20) NOT NULL REFERENCES pacientes(paciente_id) ON DELETE RESTRICT,
    medico_id VARCHAR(20) NOT NULL REFERENCES medicos(medico_id),
    cama_id VARCHAR(15) REFERENCES camas(cama_id),
    fecha_ingreso TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    diagnostico_ingreso VARCHAR(15) NOT NULL,
    estado_admision VARCHAR(20) DEFAULT 'ACTIVA'
);

-- 5. Tabla Relacional de Logs (Utilizada exclusivamente para el benchmark comparativo SQL vs NoSQL)
CREATE TABLE signos_vitales_log (
    evento_id SERIAL PRIMARY KEY,
    admision_id INT NOT NULL REFERENCES admisiones(admision_id),
    origen_dato VARCHAR(40) NOT NULL,
    frecuencia_cardiaca INT NOT NULL,
    spo2 INT NOT NULL,
    temperatura NUMERIC(4,1) NOT NULL,
    fecha_registro TIMESTAMP NOT NULL
);

-- Índices B-Tree para optimizar cruces y métricas
CREATE INDEX idx_admisiones_paciente ON admisiones(paciente_id);
CREATE INDEX idx_admisiones_estado ON admisiones(estado_admision);
CREATE INDEX idx_sv_fecha_criticos ON signos_vitales_log(fecha_registro, spo2, frecuencia_cardiaca);
