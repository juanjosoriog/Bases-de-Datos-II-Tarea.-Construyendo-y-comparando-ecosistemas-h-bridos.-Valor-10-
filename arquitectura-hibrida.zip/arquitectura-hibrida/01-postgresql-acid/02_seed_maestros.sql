-- ============================================================================
-- 02_seed_maestros.sql
-- Población inicial de datos maestros ACID y simulación de 100,000 eventos SQL
-- ============================================================================

SET search_path TO hospitalizacion_acid;

-- Inserción de Pacientes
INSERT INTO pacientes (paciente_id, nombre_completo, fecha_nacimiento, grupo_sanguineo) VALUES
('CC-10354421', 'Ana María Jaramillo', '1984-05-12', 'O+'),
('CC-43511209', 'Mateo Gómez Restrepo', '1997-08-23', 'A+'),
('CC-71298344', 'Carlos Alberto Vélez', '1970-11-02', 'B+'),
('CC-1017234890', 'Laura Sofía Montoya', '1995-02-18', 'O-'),
('CC-32567891', 'Marta Lucía Echeverri', '1962-09-30', 'AB+');

-- Inserción de Médicos
INSERT INTO medicos (medico_id, nombre_completo, especialidad, registro_profesional) VALUES
('MED-001', 'Dr. Carlos Ospina', 'Medicina Interna', 'RM-984512'),
('MED-002', 'Dra. Sofía Restrepo', 'Cuidado Crítico', 'RM-774120'),
('MED-003', 'Dr. Andrés Felipe Rojas', 'Telemedicina y Cardiología', 'RM-651289');

-- Inserción de Camas
INSERT INTO camas (cama_id, servicio, estado) VALUES
('UCI-301', 'UCI', 'OCUPADA'),
('UCI-302', 'UCI', 'OCUPADA'),
('PISO2-204', 'Hospitalización General', 'OCUPADA'),
('TELE-001', 'Telemonitoreo Domiciliario', 'OCUPADA'),
('TELE-002', 'Telemonitoreo Domiciliario', 'OCUPADA');

-- Inserción de Admisiones Activas
INSERT INTO admisiones (admision_id, paciente_id, medico_id, cama_id, diagnostico_ingreso, estado_admision) VALUES
(1001, 'CC-10354421', 'MED-001', 'UCI-301', 'J18.9', 'ACTIVA'),
(1002, 'CC-43511209', 'MED-002', 'UCI-302', 'I21.9', 'ACTIVA'),
(1003, 'CC-71298344', 'MED-003', 'TELE-001', 'I10', 'ACTIVA'),
(1004, 'CC-1017234890', 'MED-003', 'TELE-002', 'J45.9', 'ACTIVA'),
(1005, 'CC-32567891', 'MED-001', 'PISO2-204', 'E11.9', 'ACTIVA');

-- Reiniciar secuencia de admision_id
SELECT setval('admisiones_admision_id_seq', 1005);

-- Generación de 100,000 registros de telemetría en PostgreSQL para prueba comparativa de rendimiento
INSERT INTO signos_vitales_log (admision_id, origen_dato, frecuencia_cardiaca, spo2, temperatura, fecha_registro)
SELECT 
    1001 + (floor(random() * 5))::int,
    (ARRAY['WEARABLE_CARDIO_V2', 'MONITOR_UCI_MULTIPARAM', 'APP_TELECONSULTA'])[1 + floor(random() * 3)::int],
    58 + floor(random() * 78)::int,
    88 + floor(random() * 13)::int,
    round((36.2 + random() * 2.8)::numeric, 1),
    NOW() - (random() * INTERVAL '7 days')
FROM generate_series(1, 100000);
