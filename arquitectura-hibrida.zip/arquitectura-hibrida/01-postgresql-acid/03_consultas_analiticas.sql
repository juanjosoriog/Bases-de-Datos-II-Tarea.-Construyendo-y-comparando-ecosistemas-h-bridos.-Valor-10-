-- ============================================================================
-- 03_consultas_analiticas.sql
-- Consultas relacionales y análisis de rendimiento (EXPLAIN ANALYZE)
-- ============================================================================

SET search_path TO hospitalizacion_acid;

-- 1. Consulta puntual transaccional (Búsqueda maestra por PK)
EXPLAIN ANALYZE
SELECT p.paciente_id, p.nombre_completo, a.admision_id, a.cama_id, m.nombre_completo AS medico
FROM pacientes p
JOIN admisiones a ON p.paciente_id = a.paciente_id
JOIN medicos m ON a.medico_id = m.medico_id
WHERE p.paciente_id = 'CC-10354421' AND a.estado_admision = 'ACTIVA';

-- 2. Consulta analítica equivalente para benchmark contra MongoDB Aggregation Pipeline
-- Detecta alertas críticas (SpO2 < 92% o FC > 115 bpm) en los últimos 7 días
EXPLAIN ANALYZE
SELECT 
    p.paciente_id,
    p.nombre_completo,
    COUNT(s.evento_id) AS total_alertas,
    ROUND(AVG(s.spo2), 2) AS promedio_spo2,
    MAX(s.frecuencia_cardiaca) AS pico_fc
FROM pacientes p
INNER JOIN admisiones a ON p.paciente_id = a.paciente_id
INNER JOIN signos_vitales_log s ON a.admision_id = s.admision_id
WHERE s.fecha_registro >= NOW() - INTERVAL '7 days'
  AND (s.spo2 < 92 OR s.frecuencia_cardiaca > 115)
GROUP BY p.paciente_id, p.nombre_completo
ORDER BY total_alertas DESC;
