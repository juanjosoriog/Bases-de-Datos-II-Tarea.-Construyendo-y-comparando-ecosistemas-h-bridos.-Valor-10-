// ============================================================================
// 02_ingesta_masiva_100k.js
// Simulación de ingesta masiva de 100,000 eventos de wearables y teleconsultas
// ============================================================================

use hospitalizacion_base;

const pacientesPool = [
  { id: "CC-10354421", adm: 1001 },
  { id: "CC-43511209", adm: 1002 },
  { id: "CC-71298344", adm: 1003 },
  { id: "CC-1017234890", adm: 1004 },
  { id: "CC-32567891", adm: 1005 }
];

const origenes = ["WEARABLE_CARDIO_V2", "MONITOR_UCI_MULTIPARAM", "APP_TELECONSULTA"];
const batchSize = 5000;
const totalRegistros = 100000;

print("Iniciando ingesta masiva de " + totalRegistros + " eventos...");
const inicio = new Date();

for (let i = 0; i < totalRegistros / batchSize; i++) {
  let bulkOps = [];
  for (let j = 0; j < batchSize; j++) {
    let pac = pacientesPool[Math.floor(Math.random() * pacientesPool.length)];
    let spo2 = Math.floor(Math.random() * (100 - 88 + 1)) + 88;
    let fc = Math.floor(Math.random() * (135 - 58 + 1)) + 58;
    let origen = origenes[Math.floor(Math.random() * origenes.length)];

    let doc = {
      paciente_id: pac.id,
      admision_id: NumberInt(pac.adm),
      origen_dato: origen,
      timestamp: new Date(Date.now() - Math.floor(Math.random() * 86400000 * 7)),
      metricas_vitales: {
        frecuencia_cardiaca_bpm: NumberInt(fc),
        saturacion_spo2: NumberInt(spo2),
        temperatura_c: Number((36.2 + Math.random() * 2.8).toFixed(1))
      },
      alerta_critica: (spo2 < 92 || fc > 115)
    };

    // Polimorfismo: Si proviene de teleconsulta, añade metadatos adicionales sin alterar esquema
    if (origen === "APP_TELECONSULTA") {
      doc.contexto_teleconsulta = {
        sintomas_reportados: ["Fatiga leve", "Tos seca"],
        calidad_conexion: "HD_ESTABLE"
      };
    }

    bulkOps.push({ insertOne: { document: doc } });
  }
  db.telemetria_eventos.bulkWrite(bulkOps, { ordered: false });
}

const fin = new Date();
print("Ingesta completada en: " + (fin - inicio) + " ms");

// Creación de índices compuestos aplicando regla ESR (Equality, Sort, Range)
db.telemetria_eventos.createIndex({ "alerta_critica": 1, "timestamp": -1 });
db.telemetria_eventos.createIndex({ "paciente_id": 1, "timestamp": -1 });
print("Índices compuestos ESR creados exitosamente.");
