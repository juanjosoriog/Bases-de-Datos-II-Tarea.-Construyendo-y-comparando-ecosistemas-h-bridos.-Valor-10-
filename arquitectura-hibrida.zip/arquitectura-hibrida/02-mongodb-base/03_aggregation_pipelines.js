// ============================================================================
// 03_aggregation_pipelines.js
// Pipelines de analítica clínica y verificación de plan de ejecución (explain)
// ============================================================================

use hospitalizacion_base;

// Pipeline 1: Detección de alertas críticas por paciente (últimos 7 días)
const pipelineAlertas = [
  {
    $match: {
      alerta_critica: true,
      timestamp: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
    }
  },
  {
    $group: {
      _id: "$paciente_id",
      total_alertas: { $sum: 1 },
      promedio_spo2: { $avg: "$metricas_vitales.saturacion_spo2" },
      pico_fc: { $max: "$metricas_vitales.frecuencia_cardiaca_bpm" }
    }
  },
  {
    $project: {
      paciente_id: "$_id",
      total_alertas: 1,
      promedio_spo2: { $round: ["$promedio_spo2", 2] },
      pico_fc: 1,
      _id: 0
    }
  },
  { $sort: { total_alertas: -1 } }
];

print("=== RESULTADOS DE AGREGACIÓN DE ALERTAS ===");
printjson(db.telemetria_eventos.aggregate(pipelineAlertas).toArray());

print("=== MÉTRICAS DE EJECUCIÓN (EXPLAIN) ===");
const explainStats = db.telemetria_eventos.explain("executionStats").aggregate(pipelineAlertas);
print("Tiempo de ejecución (ms): " + explainStats.stages[0].$cursor.executionStats.executionTimeMillis);
print("Documentos examinados: " + explainStats.stages[0].$cursor.executionStats.totalDocsExamined);
