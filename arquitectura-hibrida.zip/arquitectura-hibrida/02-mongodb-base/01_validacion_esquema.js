// ============================================================================
// 01_validacion_esquema.js
// Configuración de colección y validación flexible JSON Schema en MongoDB
// ============================================================================

use hospitalizacion_base;

db.telemetria_eventos.drop();

db.createCollection("telemetria_eventos", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["paciente_id", "admision_id", "origen_dato", "timestamp", "metricas_vitales"],
      properties: {
        paciente_id: {
          bsonType: "string",
          description: "Llave de correlación obligatoria con PostgreSQL (pacientes.paciente_id)"
        },
        admision_id: {
          bsonType: "int",
          description: "Identificador del episodio activo en PostgreSQL"
        },
        origen_dato: {
          bsonType: "string",
          description: "Fuente del evento: WEARABLE, MONITOR_UCI, TELECONSULTA"
        },
        timestamp: {
          bsonType: "date",
          description: "Marca de tiempo UTC del evento clínico"
        },
        metricas_vitales: {
          bsonType: "object",
          required: ["frecuencia_cardiaca_bpm", "saturacion_spo2"],
          properties: {
            frecuencia_cardiaca_bpm: { bsonType: "int" },
            saturacion_spo2: { bsonType: "int" }
          }
        }
      }
    }
  },
  validationLevel: "moderate" // Permite evolución flexible de nuevos campos de sensores
});

print("Colección 'telemetria_eventos' creada con esquema flexible.");
